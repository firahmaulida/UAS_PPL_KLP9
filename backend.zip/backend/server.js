const express = require("express");
const cors = require("cors");
const db = require("./db");
const path = require("path");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Test API
app.get("/", (req, res) => {
  res.send("API berjalan 🚀");
});

// --- BAGIAN ROUTES (SUDAH DIPERBAIKI) ---

const authRoutes = require("./routes/auth");
const productRoutes = require("./routes/productRoutes");
const produkBaruRoutes = require("./routes/produk"); // Dibedakan namanya agar tidak bentrok
const chatRoutes = require("./routes/chatRoutes");
const chatLamaRoutes = require("./routes/chat"); // Dibedakan namanya agar tidak bentrok

// Daftarkan Route
app.use("/api", authRoutes);
app.use("/api", productRoutes);
app.use("/api", chatRoutes);

// Tambahan rute dari kawan/tugas baru kamu
app.use("/api/produk", produkBaruRoutes);
app.use("/api/chat-v2", chatLamaRoutes); // Gunakan path berbeda agar tidak tabrakan

// --- KONEKSI DATABASE ---
db.connect((err) => {
  if (err) {
    console.error("❌ Gagal konek ke database:", err);
  } else {
    console.log("✅ Berhasil konek ke MySQL");
  }
});

// Error handler
app.use((err, req, res, next) => {
  console.error("🔥 ERROR SERVER:", err.stack);
  res.status(500).json({ message: "Terjadi kesalahan di server" });
});

// Route tidak ditemukan
app.use((req, res) => {
  res.status(404).json({ message: "Route tidak ditemukan" });
});

// Jalankan server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server jalan di http://localhost:${PORT}`);
  console.log(`📝 Register: POST http://localhost:${PORT}/api/register`);
  console.log(`🔐 Login: POST http://localhost:${PORT}/api/login`);
});
